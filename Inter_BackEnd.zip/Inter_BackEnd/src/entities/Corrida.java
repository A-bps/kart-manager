package entities;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Corrida {
    private int nr;
    private BigDecimal preco;
    private LocalDate data;
    private LocalTime horario;
    private Pista pista;
    private Funcionario funcionario;

    public Corrida() {
    }

    public Corrida(int nr, BigDecimal preco, LocalDate data, LocalTime horario, Pista pista, Funcionario funcionario) {
        this.nr = nr;
        this.preco = preco;
        this.data = data;
        this.horario = horario;
        this.pista = pista;
        this.funcionario = funcionario;
    }

    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public BigDecimal getPreco() {
        return preco;
    }

    public void setPreco(BigDecimal preco) {
        this.preco = preco;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public void setHorario(LocalTime horario) {
        this.horario = horario;
    }

    public Pista getPista() {
        return pista;
    }

    public void setPista(Pista pista) {
        this.pista = pista;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    public void lerDados(Scanner sc) {
        boolean valido;
        do {
            System.out.print("Numero da corrida: ");
            String entrada = sc.nextLine().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor <= 0) {
                    throw new IllegalArgumentException("Numero da corrida deve ser maior que zero.");
                }
                this.nr = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Preco: ");
            String entrada = sc.nextLine().trim();
            try {
                BigDecimal valor = new BigDecimal(entrada);
                if (valor.compareTo(BigDecimal.ZERO) <= 0) {
                    throw new IllegalArgumentException("Preco deve ser maior que zero.");
                }
                this.preco = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Data (YYYY-MM-DD): ");
            String entrada = sc.nextLine().trim();
            try {
                this.data = LocalDate.parse(entrada);
                validarData();
                valido = true;
            } catch (DateTimeParseException | IllegalArgumentException ex) {
                System.out.println("Data invalida.");
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Horario (HH:MM): ");
            String entrada = sc.nextLine().trim();
            try {
                this.horario = LocalTime.parse(entrada);
                validarHorario();
                valido = true;
            } catch (DateTimeParseException | IllegalArgumentException ex) {
                System.out.println("Horario invalido.");
                valido = false;
            }
        } while (!valido);

        if (pista == null) {
            pista = new Pista();
            pista.lerDados(sc);
        }

        if (funcionario == null) {
            funcionario = new Funcionario();
            funcionario.lerDados(sc);
        }
    }

    public void validarAgendamento(List<Corrida> corridasExistentes) {
        validarData();
        validarHorario();
        if (pista == null) {
            throw new IllegalArgumentException("Pista eh obrigatoria para agendamento.");
        }
        pista.validar();

        if (corridasExistentes != null) {
            for (Corrida corrida : corridasExistentes) {
                if (corrida != null
                        && corrida.getPista() != null
                        && corrida.getData() != null
                        && corrida.getHorario() != null
                        && corrida.getPista().getNr() == pista.getNr()
                        && corrida.getData().equals(data)
                        && corrida.getHorario().equals(horario)
                        && corrida.getNr() != this.nr) {
                    throw new IllegalArgumentException("Conflito de horario na pista.");
                }
            }
        }
    }

    public void validarFormato(String formato) {
        if (formato == null || formato.trim().isEmpty()) {
            throw new IllegalArgumentException("Formato da bateria eh obrigatorio.");
        }
    }

    public void validarParticipantes(int participantes) {
        if (participantes <= 0) {
            throw new IllegalArgumentException("Numero de participantes deve ser maior que zero.");
        }
    }

    public void validar() {
        if (nr <= 0) {
            throw new IllegalArgumentException("Numero da corrida deve ser maior que zero.");
        }
        if (preco == null || preco.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Preco deve ser maior que zero.");
        }
        validarAgendamento(null);
        if (funcionario == null) {
            throw new IllegalArgumentException("Funcionario eh obrigatorio.");
        }
    }

    private void validarData() {
        if (data == null) {
            throw new IllegalArgumentException("Data da corrida eh obrigatoria.");
        }
    }

    private void validarHorario() {
        if (horario == null) {
            throw new IllegalArgumentException("Horario da corrida eh obrigatorio.");
        }
    }

    @Override
    public String toString() {
        return "Corrida{" +
                "nr=" + nr +
                ", preco=" + preco +
                ", data=" + data +
                ", horario=" + horario +
                ", pista=" + pista +
                ", funcionario=" + funcionario +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Corrida corrida = (Corrida) o;
        return nr == corrida.nr;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nr);
    }
}
