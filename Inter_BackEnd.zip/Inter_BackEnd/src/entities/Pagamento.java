package entities;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.Scanner;

public class Pagamento {
    private int codigo;
    private BigDecimal valor;
    private String status;
    private String formaPagamento;
    private Cliente cliente;
    private Corrida corrida;

    public Pagamento() {
    }

    public Pagamento(int codigo, BigDecimal valor, String status, String formaPagamento, Cliente cliente, Corrida corrida) {
        this.codigo = codigo;
        this.valor = valor;
        this.status = status;
        this.formaPagamento = formaPagamento;
        this.cliente = cliente;
        this.corrida = corrida;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Corrida getCorrida() {
        return corrida;
    }

    public void setCorrida(Corrida corrida) {
        this.corrida = corrida;
    }

    public void lerDados(Scanner sc) {
        boolean valido;
        do {
            System.out.print("Codigo do pagamento: ");
            String entrada = sc.nextLine().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor <= 0) {
                    throw new IllegalArgumentException("Codigo deve ser maior que zero.");
                }
                this.codigo = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Valor do pagamento: ");
            String entrada = sc.nextLine().trim();
            try {
                BigDecimal valor = new BigDecimal(entrada);
                if (valor.compareTo(BigDecimal.ZERO) <= 0) {
                    throw new IllegalArgumentException("Valor deve ser maior que zero.");
                }
                this.valor = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Status do pagamento: ");
            String entrada = sc.nextLine().trim();
            try {
                this.status = entrada;
                validarStatus();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Forma de pagamento: ");
            String entrada = sc.nextLine().trim();
            try {
                this.formaPagamento = entrada;
                validarFormaPagamento();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        if (cliente == null) {
            cliente = new Cliente();
            cliente.lerDados(sc);
        }
        if (corrida == null) {
            corrida = new Corrida();
            corrida.lerDados(sc);
        }
    }

    public void validar() {
        if (codigo <= 0) {
            throw new IllegalArgumentException("Codigo do pagamento deve ser maior que zero.");
        }
        if (valor == null || valor.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Valor do pagamento deve ser maior que zero.");
        }
        validarStatus();
        validarFormaPagamento();
        if (cliente == null) {
            throw new IllegalArgumentException("Cliente do pagamento eh obrigatorio.");
        }
        if (corrida == null) {
            throw new IllegalArgumentException("Corrida do pagamento eh obrigatoria.");
        }
    }

    public String gerarComprovante() {
        validar();
        if (!"pago".equalsIgnoreCase(status)) {
            throw new IllegalArgumentException("Pagamento ainda nao esta pago.");
        }
        return "Comprovante: pagamento " + codigo + " - valor " + valor + " - status " + status;
    }

    private void validarStatus() {
        if (status == null || status.trim().isEmpty()) {
            throw new IllegalArgumentException("Status do pagamento eh obrigatorio.");
        }
    }

    private void validarFormaPagamento() {
        if (formaPagamento == null || formaPagamento.trim().isEmpty()) {
            throw new IllegalArgumentException("Forma de pagamento eh obrigatoria.");
        }
    }

    @Override
    public String toString() {
        return "Pagamento{" +
                "codigo=" + codigo +
                ", valor=" + valor +
                ", status='" + status + '\'' +
                ", formaPagamento='" + formaPagamento + '\'' +
                ", cliente=" + cliente +
                ", corrida=" + corrida +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Pagamento pagamento = (Pagamento) o;
        return codigo == pagamento.codigo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
