package entities;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Cliente {
    private Pessoa pessoa;
    private LocalDate dataNascimento;

    public Cliente() {
    }

    public Cliente(Pessoa pessoa, LocalDate dataNascimento) {
        this.pessoa = pessoa;
        this.dataNascimento = dataNascimento;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public void lerDados(Scanner sc) {
        if (pessoa == null) {
            pessoa = new Pessoa();
            pessoa.lerDados(sc);
        }

        boolean valido;
        do {
            System.out.print("Data de nascimento (YYYY-MM-DD): ");
            String entrada = sc.nextLine().trim();
            try {
                this.dataNascimento = LocalDate.parse(entrada);
                validarDataNascimento();
                valido = true;
            } catch (DateTimeParseException | IllegalArgumentException ex) {
                System.out.println("Data de nascimento invalida.");
                valido = false;
            }
        } while (!valido);
    }

    public void validarCadastro(List<Cliente> existentes, List<Pessoa> pessoasExistentes) {
        if (pessoa == null) {
            throw new IllegalArgumentException("Pessoa do cliente eh obrigatoria.");
        }
        pessoa.validarCadastro(pessoasExistentes);
        validarDataNascimento();

        if (existentes != null) {
            for (Cliente cliente : existentes) {
                if (cliente != null
                        && cliente.getPessoa() != null
                        && cliente.getPessoa().getCpf() != null
                        && cliente.getPessoa().getCpf().equals(pessoa.getCpf())
                        && cliente != this) {
                    throw new IllegalArgumentException("CPF ja cadastrado para outro cliente.");
                }
            }
        }
    }

    public void validarCadastro(List<Cliente> existentes) {
        validarCadastro(existentes, null);
    }

    public void validarHistorico(List<ClienteCorrida> historico) {
        if (historico == null || historico.isEmpty()) {
            throw new IllegalArgumentException("Cliente nao possui historico de corridas.");
        }
    }

    private void validarDataNascimento() {
        if (dataNascimento == null) {
            throw new IllegalArgumentException("Data de nascimento eh obrigatoria.");
        }
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "pessoa=" + pessoa +
                ", dataNascimento=" + dataNascimento +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Cliente cliente = (Cliente) o;
        return Objects.equals(pessoa, cliente.pessoa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pessoa);
    }
}
