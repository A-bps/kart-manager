package entities;

import java.util.Objects;
import java.util.Scanner;

public class Cidade {
    private int codigo;
    private String nome;
    private Uf uf;

    public Cidade() {
    }

    public Cidade(int codigo, String nome, Uf uf) {
        this.codigo = codigo;
        this.nome = nome;
        this.uf = uf;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Uf getUf() {
        return uf;
    }

    public void setUf(Uf uf) {
        this.uf = uf;
    }

    public void lerDados(Scanner sc) {
        boolean valido;
        do {
            System.out.print("Codigo da cidade: ");
            String entrada = sc.nextLine().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor <= 0) {
                    throw new IllegalArgumentException("Codigo deve ser maior que zero.");
                }
                this.codigo = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Nome da cidade: ");
            String entrada = sc.nextLine().trim();
            try {
                this.nome = entrada;
                validarNome();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        if (uf == null) {
            uf = new Uf();
            uf.lerDados(sc);
        }
        validarUf();
    }

    public void validar() {
        validarCodigo();
        validarNome();
        validarUf();
    }

    private void validarCodigo() {
        if (codigo <= 0) {
            throw new IllegalArgumentException("Codigo da cidade deve ser maior que zero.");
        }
    }

    private void validarNome() {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome da cidade eh obrigatorio.");
        }
    }

    private void validarUf() {
        if (uf == null) {
            throw new IllegalArgumentException("UF eh obrigatoria.");
        }
        uf.validar();
    }

    @Override
    public String toString() {
        return "Cidade{" +
                "codigo=" + codigo +
                ", nome='" + nome + '\'' +
                ", uf=" + uf +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Cidade cidade = (Cidade) o;
        return codigo == cidade.codigo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
