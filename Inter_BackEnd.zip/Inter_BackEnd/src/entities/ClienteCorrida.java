package entities;

import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;
import java.util.Set;

public class ClienteCorrida {
    private Cliente cliente;
    private Corrida corrida;
    private LocalTime melhorVolta;
    private String penalidade;
    private LocalTime tempo;
    private Integer posicao;

    public ClienteCorrida() {
    }

    public ClienteCorrida(Cliente cliente, Corrida corrida, LocalTime melhorVolta, String penalidade, LocalTime tempo, Integer posicao) {
        this.cliente = cliente;
        this.corrida = corrida;
        this.melhorVolta = melhorVolta;
        this.penalidade = penalidade;
        this.tempo = tempo;
        this.posicao = posicao;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Corrida getCorrida() {
        return corrida;
    }

    public void setCorrida(Corrida corrida) {
        this.corrida = corrida;
    }

    public LocalTime getMelhorVolta() {
        return melhorVolta;
    }

    public void setMelhorVolta(LocalTime melhorVolta) {
        this.melhorVolta = melhorVolta;
    }

    public String getPenalidade() {
        return penalidade;
    }

    public void setPenalidade(String penalidade) {
        this.penalidade = penalidade;
    }

    public LocalTime getTempo() {
        return tempo;
    }

    public void setTempo(LocalTime tempo) {
        this.tempo = tempo;
    }

    public Integer getPosicao() {
        return posicao;
    }

    public void setPosicao(Integer posicao) {
        this.posicao = posicao;
    }

    public void lerDados(Scanner sc) {
        if (cliente == null) {
            cliente = new Cliente();
            cliente.lerDados(sc);
        }
        if (corrida == null) {
            corrida = new Corrida();
            corrida.lerDados(sc);
        }

        boolean valido;
        do {
            System.out.print("Melhor volta (HH:MM:SS): ");
            String entrada = sc.nextLine().trim();
            try {
                this.melhorVolta = LocalTime.parse(entrada);
                valido = true;
            } catch (DateTimeParseException ex) {
                System.out.println("Melhor volta invalida.");
                valido = false;
            }
        } while (!valido);

        System.out.print("Penalidade (opcional): ");
        String entrada = sc.nextLine().trim();
        this.penalidade = entrada.isEmpty() ? null : entrada;

        do {
            System.out.print("Tempo total (HH:MM:SS): ");
            entrada = sc.nextLine().trim();
            try {
                this.tempo = LocalTime.parse(entrada);
                validarTempo();
                valido = true;
            } catch (DateTimeParseException | IllegalArgumentException ex) {
                System.out.println("Tempo total invalido.");
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Posicao final: ");
            entrada = sc.nextLine().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor <= 0) {
                    throw new IllegalArgumentException("Posicao deve ser maior que zero.");
                }
                this.posicao = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);
    }

    public void validarResultados() {
        if (cliente == null) {
            throw new IllegalArgumentException("Cliente eh obrigatorio.");
        }
        if (corrida == null) {
            throw new IllegalArgumentException("Corrida eh obrigatoria.");
        }
        if (melhorVolta == null) {
            throw new IllegalArgumentException("Melhor volta eh obrigatoria.");
        }
        validarTempo();
        if (posicao == null || posicao <= 0) {
            throw new IllegalArgumentException("Posicao final invalida.");
        }
    }

    public void validarRanking(List<ClienteCorrida> resultados) {
        if (resultados == null || resultados.isEmpty()) {
            throw new IllegalArgumentException("Nao ha resultados para ranking.");
        }
        Set<Integer> posicoes = new HashSet<>();
        for (ClienteCorrida item : resultados) {
            if (item == null || item.getPosicao() == null) {
                throw new IllegalArgumentException("Resultado com posicao invalida.");
            }
            if (!posicoes.add(item.getPosicao())) {
                throw new IllegalArgumentException("Posicoes duplicadas no ranking.");
            }
        }
    }

    private void validarTempo() {
        if (tempo == null) {
            throw new IllegalArgumentException("Tempo total eh obrigatorio.");
        }
    }

    @Override
    public String toString() {
        return "ClienteCorrida{" +
                "cliente=" + cliente +
                ", corrida=" + corrida +
                ", melhorVolta=" + melhorVolta +
                ", penalidade='" + penalidade + '\'' +
                ", tempo=" + tempo +
                ", posicao=" + posicao +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        ClienteCorrida that = (ClienteCorrida) o;
        return Objects.equals(cliente, that.cliente) && Objects.equals(corrida, that.corrida);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cliente, corrida);
    }
}
