package entities;

import java.util.Objects;
import java.util.Scanner;

public class CorridaKart {
    private Corrida corrida;
    private Kart kart;

    public CorridaKart() {
    }

    public CorridaKart(Corrida corrida, Kart kart) {
        this.corrida = corrida;
        this.kart = kart;
    }

    public Corrida getCorrida() {
        return corrida;
    }

    public void setCorrida(Corrida corrida) {
        this.corrida = corrida;
    }

    public Kart getKart() {
        return kart;
    }

    public void setKart(Kart kart) {
        this.kart = kart;
    }

    public void lerDados(Scanner sc) {
        if (corrida == null) {
            corrida = new Corrida();
            corrida.lerDados(sc);
        }
        if (kart == null) {
            kart = new Kart();
            kart.lerDados(sc);
        }
    }

    public void validar() {
        if (corrida == null) {
            throw new IllegalArgumentException("Corrida eh obrigatoria.");
        }
        if (kart == null) {
            throw new IllegalArgumentException("Kart eh obrigatorio.");
        }
    }

    @Override
    public String toString() {
        return "CorridaKart{" +
                "corrida=" + corrida +
                ", kart=" + kart +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CorridaKart that = (CorridaKart) o;
        return Objects.equals(corrida, that.corrida) && Objects.equals(kart, that.kart);
    }

    @Override
    public int hashCode() {
        return Objects.hash(corrida, kart);
    }
}
