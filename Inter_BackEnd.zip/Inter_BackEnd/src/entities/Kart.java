package entities;

import java.text.Normalizer;
import java.util.Objects;
import java.util.Scanner;

public class Kart {
    private int codigo;
    private String estado;
    private String historico;

    public Kart() {
    }

    public Kart(int codigo, String estado, String historico) {
        this.codigo = codigo;
        this.estado = estado;
        this.historico = historico;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getHistorico() {
        return historico;
    }

    public void setHistorico(String historico) {
        this.historico = historico;
    }

    public void lerDados(Scanner sc) {
        boolean valido;
        do {
            System.out.print("Codigo do kart: ");
            String entrada = sc.nextLine().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor <= 0) {
                    throw new IllegalArgumentException("Codigo do kart deve ser maior que zero.");
                }
                this.codigo = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Estado do kart: ");
            String entrada = sc.nextLine().trim();
            try {
                this.estado = entrada;
                validarEstado();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        System.out.print("Historico (opcional): ");
        String entrada = sc.nextLine().trim();
        this.historico = entrada.isEmpty() ? null : entrada;
    }

    public void validar() {
        if (codigo <= 0) {
            throw new IllegalArgumentException("Codigo do kart deve ser maior que zero.");
        }
        validarEstado();
    }

    public boolean estaDisponivel() {
        if (estado == null) {
            return false;
        }
        String estadoNormalizado = Normalizer.normalize(estado, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .trim()
                .toLowerCase();
        return !estadoNormalizado.contains("indisponivel")
                && !estadoNormalizado.contains("manutencao");
    }

    private void validarEstado() {
        if (estado == null || estado.trim().isEmpty()) {
            throw new IllegalArgumentException("Estado do kart eh obrigatorio.");
        }
    }

    @Override
    public String toString() {
        return "Kart{" +
                "codigo=" + codigo +
                ", estado='" + estado + '\'' +
                ", historico='" + historico + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Kart kart = (Kart) o;
        return codigo == kart.codigo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
