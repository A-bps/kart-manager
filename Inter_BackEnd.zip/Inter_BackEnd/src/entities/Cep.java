package entities;

import java.util.Objects;
import java.util.Scanner;

public class Cep {
    private String numero;
    private Cidade cidade;

    public Cep() {
    }

    public Cep(String numero, Cidade cidade) {
        this.numero = numero;
        this.cidade = cidade;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Cidade getCidade() {
        return cidade;
    }

    public void setCidade(Cidade cidade) {
        this.cidade = cidade;
    }

    public void lerDados(Scanner sc) {
        boolean valido;
        do {
            System.out.print("CEP (8 digitos): ");
            String entrada = sc.nextLine().trim();
            try {
                this.numero = entrada;
                validarNumero();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        if (cidade == null) {
            cidade = new Cidade();
            cidade.lerDados(sc);
        }
        validarCidade();
    }

    public void validar() {
        validarNumero();
        validarCidade();
    }

    private void validarNumero() {
        if (numero == null || !numero.matches("\\d{8}")) {
            throw new IllegalArgumentException("CEP deve conter 8 digitos.");
        }
    }

    private void validarCidade() {
        if (cidade == null) {
            throw new IllegalArgumentException("Cidade eh obrigatoria para o CEP.");
        }
        cidade.validar();
    }

    @Override
    public String toString() {
        return "Cep{" +
                "numero='" + numero + '\'' +
                ", cidade=" + cidade +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Cep cep = (Cep) o;
        return Objects.equals(numero, cep.numero);
    }

    @Override
    public int hashCode() {
        return Objects.hash(numero);
    }
}
