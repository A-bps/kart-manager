package entities;

import java.util.Objects;
import java.util.Scanner;

public class Pista {
    private int nr;
    private String nome;

    public Pista() {
    }

    public Pista(int nr, String nome) {
        this.nr = nr;
        this.nome = nome;
    }

    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void lerDados(Scanner sc) {
        boolean valido;
        do {
            System.out.print("Numero da pista: ");
            String entrada = sc.nextLine().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor <= 0) {
                    throw new IllegalArgumentException("Numero da pista deve ser maior que zero.");
                }
                this.nr = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Nome da pista: ");
            String entrada = sc.nextLine().trim();
            try {
                this.nome = entrada;
                validarNome();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);
    }

    public void validar() {
        if (nr <= 0) {
            throw new IllegalArgumentException("Numero da pista deve ser maior que zero.");
        }
        validarNome();
    }

    private void validarNome() {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome da pista eh obrigatorio.");
        }
    }

    @Override
    public String toString() {
        return "Pista{" +
                "nr=" + nr +
                ", nome='" + nome + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Pista pista = (Pista) o;
        return nr == pista.nr;
    }

    @Override
    public int hashCode() {
        return Objects.hash(nr);
    }
}
