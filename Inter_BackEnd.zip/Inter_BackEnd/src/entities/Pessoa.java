package entities;

import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Pessoa {
    private int codigo;
    private String nome;
    private String cpf;
    private String email;
    private String fone;
    private Cep cep;

    public Pessoa() {
    }

    public Pessoa(int codigo, String nome, String cpf, String email, String fone, Cep cep) {
        this.codigo = codigo;
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.fone = fone;
        this.cep = cep;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public Cep getCep() {
        return cep;
    }

    public void setCep(Cep cep) {
        this.cep = cep;
    }

    public void lerDados(Scanner sc) {
        boolean valido;
        do {
            System.out.print("Codigo da pessoa: ");
            String entrada = sc.nextLine().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor <= 0) {
                    throw new IllegalArgumentException("Codigo deve ser maior que zero.");
                }
                this.codigo = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Nome: ");
            String entrada = sc.nextLine().trim();
            try {
                this.nome = entrada;
                validarNome();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("CPF (11 digitos): ");
            String entrada = sc.nextLine().trim();
            try {
                this.cpf = entrada;
                validarCpf();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Email (opcional): ");
            String entrada = sc.nextLine().trim();
            try {
                this.email = entrada.isEmpty() ? null : entrada;
                validarEmail();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Telefone (opcional): ");
            String entrada = sc.nextLine().trim();
            try {
                this.fone = entrada.isEmpty() ? null : entrada;
                validarFone();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        if (cep == null) {
            cep = new Cep();
            cep.lerDados(sc);
        }
        validarCep();
    }

    public void validarCadastro(List<Pessoa> existentes) {
        validarBasico();
        if (existentes != null) {
            for (Pessoa pessoa : existentes) {
                if (pessoa != null
                        && pessoa.getCpf() != null
                        && pessoa.getCpf().equals(this.cpf)
                        && pessoa.getCodigo() != this.codigo) {
                    throw new IllegalArgumentException("CPF ja cadastrado.");
                }
            }
        }
    }

    public void validarLogin() {
        if ((cpf == null || cpf.trim().isEmpty())
                && (email == null || email.trim().isEmpty())) {
            throw new IllegalArgumentException("Informe CPF ou email para login.");
        }
    }

    public void validarEdicao(List<Pessoa> existentes) {
        validarCadastro(existentes);
    }

    private void validarBasico() {
        validarNome();
        validarCpf();
        validarCep();
        validarEmail();
        validarFone();
    }

    private void validarNome() {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome eh obrigatorio.");
        }
    }

    private void validarCpf() {
        if (cpf == null || !cpf.matches("\\d{11}")) {
            throw new IllegalArgumentException("CPF deve conter 11 digitos.");
        }
    }

    private void validarEmail() {
        if (email != null && !email.isEmpty() && !email.contains("@")) {
            throw new IllegalArgumentException("Email invalido.");
        }
    }

    private void validarFone() {
        if (fone != null && !fone.isEmpty() && fone.length() < 8) {
            throw new IllegalArgumentException("Telefone invalido.");
        }
    }

    private void validarCep() {
        if (cep == null) {
            throw new IllegalArgumentException("CEP eh obrigatorio.");
        }
        cep.validar();
    }

    @Override
    public String toString() {
        return "Pessoa{" +
                "codigo=" + codigo +
                ", nome='" + nome + '\'' +
                ", cpf='" + cpf + '\'' +
                ", email='" + email + '\'' +
                ", fone='" + fone + '\'' +
                ", cep=" + cep +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Pessoa pessoa = (Pessoa) o;
        return codigo == pessoa.codigo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
