package entities;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Gerente {
    private Pessoa pessoa;
    private BigDecimal salarioExtra;

    public Gerente() {
    }

    public Gerente(Pessoa pessoa, BigDecimal salarioExtra) {
        this.pessoa = pessoa;
        this.salarioExtra = salarioExtra;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public BigDecimal getSalarioExtra() {
        return salarioExtra;
    }

    public void setSalarioExtra(BigDecimal salarioExtra) {
        this.salarioExtra = salarioExtra;
    }

    public void lerDados(Scanner sc) {
        if (pessoa == null) {
            pessoa = new Pessoa();
            pessoa.lerDados(sc);
        }

        boolean valido;
        do {
            System.out.print("Salario extra: ");
            String entrada = sc.nextLine().trim();
            try {
                BigDecimal valor = new BigDecimal(entrada);
                if (valor.compareTo(BigDecimal.ZERO) <= 0) {
                    throw new IllegalArgumentException("Salario extra deve ser maior que zero.");
                }
                this.salarioExtra = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);
    }

    public void validar() {
        validar(null);
    }

    public void validar(List<Pessoa> pessoasExistentes) {
        if (pessoa == null) {
            throw new IllegalArgumentException("Pessoa do gerente eh obrigatoria.");
        }
        pessoa.validarCadastro(pessoasExistentes);
        if (salarioExtra == null || salarioExtra.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Salario extra deve ser maior que zero.");
        }
    }

    @Override
    public String toString() {
        return "Gerente{" +
                "pessoa=" + pessoa +
                ", salarioExtra=" + salarioExtra +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Gerente gerente = (Gerente) o;
        return Objects.equals(pessoa, gerente.pessoa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pessoa);
    }
}
