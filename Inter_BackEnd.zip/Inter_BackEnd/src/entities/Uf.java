package entities;

import java.util.Objects;
import java.util.Scanner;

public class Uf {
    private String sigla;
    private String nome;

    public Uf() {
    }

    public Uf(String sigla, String nome) {
        this.sigla = sigla;
        this.nome = nome;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void lerDados(Scanner sc) {
        String entrada;
        do {
            System.out.print("Sigla (2 letras): ");
            entrada = sc.nextLine().trim();
            try {
                this.sigla = entrada.toUpperCase();
                validarSigla();
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                entrada = "";
            }
        } while (entrada.isEmpty());

        do {
            System.out.print("Nome da UF: ");
            entrada = sc.nextLine().trim();
            try {
                this.nome = entrada;
                validarNome();
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                entrada = "";
            }
        } while (entrada.isEmpty());
    }

    public void validar() {
        validarSigla();
        validarNome();
    }

    private void validarSigla() {
        if (sigla == null || sigla.trim().length() != 2) {
            throw new IllegalArgumentException("Sigla da UF deve ter 2 caracteres.");
        }
    }

    private void validarNome() {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome da UF eh obrigatorio.");
        }
    }

    @Override
    public String toString() {
        return "Uf{" +
                "sigla='" + sigla + '\'' +
                ", nome='" + nome + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Uf uf = (Uf) o;
        return Objects.equals(sigla, uf.sigla);
    }

    @Override
    public int hashCode() {
        return Objects.hash(sigla);
    }
}
