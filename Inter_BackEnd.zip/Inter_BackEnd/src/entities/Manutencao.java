package entities;

import java.math.BigDecimal;
import java.util.Objects;
import java.util.Scanner;

public class Manutencao {
    private int codigo;
    private String status;
    private BigDecimal valor;
    private String formaPagamento;
    private Kart kart;

    public Manutencao() {
    }

    public Manutencao(int codigo, String status, BigDecimal valor, String formaPagamento, Kart kart) {
        this.codigo = codigo;
        this.status = status;
        this.valor = valor;
        this.formaPagamento = formaPagamento;
        this.kart = kart;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getValor() {
        return valor;
    }

    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public Kart getKart() {
        return kart;
    }

    public void setKart(Kart kart) {
        this.kart = kart;
    }

    public void lerDados(Scanner sc) {
        boolean valido;
        do {
            System.out.print("Codigo da manutencao: ");
            String entrada = sc.nextLine().trim();
            try {
                int valor = Integer.parseInt(entrada);
                if (valor <= 0) {
                    throw new IllegalArgumentException("Codigo deve ser maior que zero.");
                }
                this.codigo = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Status da manutencao: ");
            String entrada = sc.nextLine().trim();
            try {
                this.status = entrada;
                validarStatus();
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        do {
            System.out.print("Valor da manutencao: ");
            String entrada = sc.nextLine().trim();
            try {
                BigDecimal valor = new BigDecimal(entrada);
                if (valor.compareTo(BigDecimal.ZERO) <= 0) {
                    throw new IllegalArgumentException("Valor deve ser maior que zero.");
                }
                this.valor = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);

        System.out.print("Forma de pagamento (opcional): ");
        String entrada = sc.nextLine().trim();
        this.formaPagamento = entrada.isEmpty() ? null : entrada;

        if (kart == null) {
            kart = new Kart();
            kart.lerDados(sc);
        }
    }

    public void validar() {
        if (codigo <= 0) {
            throw new IllegalArgumentException("Codigo da manutencao deve ser maior que zero.");
        }
        validarStatus();
        if (valor == null || valor.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Valor da manutencao deve ser maior que zero.");
        }
        if (kart == null) {
            throw new IllegalArgumentException("Kart da manutencao eh obrigatorio.");
        }
    }

    private void validarStatus() {
        if (status == null || status.trim().isEmpty()) {
            throw new IllegalArgumentException("Status da manutencao eh obrigatorio.");
        }
    }

    @Override
    public String toString() {
        return "Manutencao{" +
                "codigo=" + codigo +
                ", status='" + status + '\'' +
                ", valor=" + valor +
                ", formaPagamento='" + formaPagamento + '\'' +
                ", kart=" + kart +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Manutencao that = (Manutencao) o;
        return codigo == that.codigo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(codigo);
    }
}
