package entities;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;

public class Funcionario {
    private Pessoa pessoa;
    private BigDecimal salario;

    public Funcionario() {
    }

    public Funcionario(Pessoa pessoa, BigDecimal salario) {
        this.pessoa = pessoa;
        this.salario = salario;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public BigDecimal getSalario() {
        return salario;
    }

    public void setSalario(BigDecimal salario) {
        this.salario = salario;
    }

    public void lerDados(Scanner sc) {
        if (pessoa == null) {
            pessoa = new Pessoa();
            pessoa.lerDados(sc);
        }

        boolean valido;
        do {
            System.out.print("Salario: ");
            String entrada = sc.nextLine().trim();
            try {
                BigDecimal valor = new BigDecimal(entrada);
                if (valor.compareTo(BigDecimal.ZERO) <= 0) {
                    throw new IllegalArgumentException("Salario deve ser maior que zero.");
                }
                this.salario = valor;
                valido = true;
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                valido = false;
            }
        } while (!valido);
    }

    public void validar() {
        validar(null);
    }

    public void validar(List<Pessoa> pessoasExistentes) {
        if (pessoa == null) {
            throw new IllegalArgumentException("Pessoa do funcionario eh obrigatoria.");
        }
        pessoa.validarCadastro(pessoasExistentes);
        if (salario == null || salario.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Salario do funcionario deve ser maior que zero.");
        }
    }

    @Override
    public String toString() {
        return "Funcionario{" +
                "pessoa=" + pessoa +
                ", salario=" + salario +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Funcionario that = (Funcionario) o;
        return Objects.equals(pessoa, that.pessoa);
    }

    @Override
    public int hashCode() {
        return Objects.hash(pessoa);
    }
}
