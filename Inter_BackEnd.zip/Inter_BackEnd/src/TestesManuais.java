import entities.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TestesManuais {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<Pessoa> pessoas = new ArrayList<>();
        List<Cliente> clientes = new ArrayList<>();
        List<Corrida> corridas = new ArrayList<>();

        while (true) {
            System.out.println("\n=== Testes Manuais ===");
            System.out.println("1) Teste cadastro CPF unico");
            System.out.println("2) Teste agendamento com conflito");
            System.out.println("3) Teste pagamento e comprovante");
            System.out.println("4) Teste disponibilidade de kart");
            System.out.println("5) Teste resultados e ranking");
            System.out.println("6) Testes de sucesso");
            System.out.println("7) Teste guiado por console");
            System.out.println("0) Sair");
            System.out.print("Opcao: ");

            String opcao = sc.nextLine().trim();
            if ("0".equals(opcao)) {
                break;
            }

            try {
                switch (opcao) {
                    case "1" -> testeCpfUnico(pessoas, clientes);
                    case "2" -> testeAgendamentoConflito(corridas);
                    case "3" -> testePagamentoComprovante();
                    case "4" -> testeDisponibilidadeKart();
                    case "5" -> testeResultadosRanking();
                    case "6" -> testesSucesso(pessoas, clientes, corridas);
                    case "7" -> testeGuiado(sc, pessoas, clientes, corridas);
                    default -> System.out.println("Opcao invalida.");
                }
            } catch (IllegalArgumentException ex) {
                System.out.println("Falha: " + ex.getMessage());
            }
        }

        sc.close();
    }

    private static void testeCpfUnico(List<Pessoa> pessoas, List<Cliente> clientes) {
        Uf uf = new Uf("SP", "Sao Paulo");
        Cidade cidade = new Cidade(1, "Sao Jose dos Campos", uf);
        Cep cep = new Cep("12245580", cidade);

        Pessoa p1 = new Pessoa(1, "Ana", "12345678901", "ana@email.com", "12999999999", cep);
        Pessoa p2 = new Pessoa(2, "Bruno", "12345678901", "bruno@email.com", "12988888888", cep);

        Cliente c1 = new Cliente(p1, LocalDate.of(2000, 1, 10));
        Cliente c2 = new Cliente(p2, LocalDate.of(1999, 5, 20));

        pessoas.clear();
        clientes.clear();
        pessoas.add(p1);
        clientes.add(c1);

        c1.validarCadastro(clientes, pessoas);

        pessoas.add(p2);
        clientes.add(c2);

        // Deve falhar pois CPF eh unico entre todas as pessoas.
        c2.validarCadastro(clientes, pessoas);
    }

    private static void testeAgendamentoConflito(List<Corrida> corridas) {
        Pista pista = new Pista(1, "Pista A");
        Pessoa pessoa = new Pessoa(1, "Carlos", "98765432100", null, null,
                new Cep("12245580", new Cidade(1, "SJC", new Uf("SP", "Sao Paulo"))));
        Funcionario funcionario = new Funcionario(pessoa, new BigDecimal("3000"));

        Corrida corrida1 = new Corrida(1, new BigDecimal("100"), LocalDate.of(2026, 5, 29),
                LocalTime.of(14, 0), pista, funcionario);
        Corrida corrida2 = new Corrida(2, new BigDecimal("120"), LocalDate.of(2026, 5, 29),
                LocalTime.of(14, 0), pista, funcionario);

        corridas.clear();
        corridas.add(corrida1);

        // Deve falhar por conflito de horario e pista.
        corrida2.validarAgendamento(corridas);
    }

    private static void testePagamentoComprovante() {
        Cliente cliente = new Cliente(new Pessoa(1, "Daniela", "11122233344", null, null,
                new Cep("12245580", new Cidade(1, "SJC", new Uf("SP", "Sao Paulo")))),
                LocalDate.of(1998, 3, 12));
        Corrida corrida = new Corrida(1, new BigDecimal("150"), LocalDate.of(2026, 5, 29),
                LocalTime.of(15, 0), new Pista(1, "Pista A"),
                new Funcionario(new Pessoa(2, "Funcionario", "55566677788", null, null,
                        new Cep("12245580", new Cidade(1, "SJC", new Uf("SP", "Sao Paulo")))),
                        new BigDecimal("3500")));

        Pagamento pagamento = new Pagamento(1, new BigDecimal("150"), "Pendente", "Pix", cliente, corrida);

        // Deve falhar: status nao eh pago.
        pagamento.gerarComprovante();
    }

    private static void testeDisponibilidadeKart() {
        Kart k1 = new Kart(1, "Disponivel", null);
        Kart k2 = new Kart(2, "Em manutencao", null);
        Kart k3 = new Kart(3, "Indisponivel", null);

        System.out.println("Kart 1 disponivel? " + k1.estaDisponivel());
        System.out.println("Kart 2 disponivel? " + k2.estaDisponivel());
        System.out.println("Kart 3 disponivel? " + k3.estaDisponivel());
    }

    private static void testeResultadosRanking() {
        Cliente c1 = new Cliente(new Pessoa(1, "Eva", "00011122233", null, null,
                new Cep("12245580", new Cidade(1, "SJC", new Uf("SP", "Sao Paulo")))),
                LocalDate.of(2001, 1, 1));
        Cliente c2 = new Cliente(new Pessoa(2, "Fabio", "00011122244", null, null,
                new Cep("12245580", new Cidade(1, "SJC", new Uf("SP", "Sao Paulo")))),
                LocalDate.of(2001, 1, 2));

        Corrida corrida = new Corrida(1, new BigDecimal("100"), LocalDate.of(2026, 5, 29),
                LocalTime.of(10, 0), new Pista(1, "Pista A"),
                new Funcionario(new Pessoa(3, "Funcionario", "00011122255", null, null,
                        new Cep("12245580", new Cidade(1, "SJC", new Uf("SP", "Sao Paulo")))),
                        new BigDecimal("3000")));

        ClienteCorrida r1 = new ClienteCorrida(c1, corrida, LocalTime.of(0, 1, 10), null,
                LocalTime.of(0, 15, 0), 1);
        ClienteCorrida r2 = new ClienteCorrida(c2, corrida, LocalTime.of(0, 1, 12), null,
                LocalTime.of(0, 15, 5), 1);

        List<ClienteCorrida> resultados = new ArrayList<>();
        resultados.add(r1);
        resultados.add(r2);

        // Deve falhar: posicoes duplicadas no ranking.
        r1.validarRanking(resultados);
    }

    private static void testesSucesso(List<Pessoa> pessoas, List<Cliente> clientes, List<Corrida> corridas) {
        System.out.println("Executando testes de sucesso...");

        Uf uf = new Uf("SP", "Sao Paulo");
        Cidade cidade = new Cidade(1, "Sao Jose dos Campos", uf);
        Cep cep = new Cep("12245580", cidade);

        Pessoa p1 = new Pessoa(1, "Guilherme", "12312312312", "gui@email.com", "12999998888", cep);
        Cliente c1 = new Cliente(p1, LocalDate.of(2000, 2, 2));

        pessoas.clear();
        clientes.clear();
        pessoas.add(p1);
        clientes.add(c1);

        c1.validarCadastro(clientes, pessoas);

        Pista pista = new Pista(1, "Pista A");
        Funcionario funcionario = new Funcionario(new Pessoa(2, "Helena", "32132132132", null, null, cep),
                new BigDecimal("3200"));

        Corrida corrida = new Corrida(1, new BigDecimal("100"), LocalDate.of(2026, 5, 30),
                LocalTime.of(14, 30), pista, funcionario);

        corridas.clear();
        corridas.add(corrida);
        corrida.validarAgendamento(corridas);

        Pagamento pagamento = new Pagamento(1, new BigDecimal("100"), "Pago", "Pix", c1, corrida);
        String comprovante = pagamento.gerarComprovante();
        System.out.println(comprovante);

        ClienteCorrida r1 = new ClienteCorrida(c1, corrida, LocalTime.of(0, 1, 10), null,
                LocalTime.of(0, 15, 0), 1);
        ClienteCorrida r2 = new ClienteCorrida(new Cliente(
                new Pessoa(3, "Iara", "44455566677", null, null, cep), LocalDate.of(2001, 4, 4)),
                corrida, LocalTime.of(0, 1, 12), null, LocalTime.of(0, 15, 5), 2);

        List<ClienteCorrida> resultados = new ArrayList<>();
        resultados.add(r1);
        resultados.add(r2);
        r1.validarRanking(resultados);

        System.out.println("Testes de sucesso concluidos.");
    }

    private static void testeGuiado(Scanner sc, List<Pessoa> pessoas, List<Cliente> clientes, List<Corrida> corridas) {
        System.out.println("\n=== Teste Guiado ===");
        System.out.println("1) Pessoa");
        System.out.println("2) Cliente");
        System.out.println("3) Corrida");
        System.out.println("4) Pagamento");
        System.out.println("5) Kart");
        System.out.print("Escolha: ");

        String opcao = sc.nextLine().trim();
        switch (opcao) {
            case "1" -> {
                Pessoa pessoa = new Pessoa();
                pessoa.lerDados(sc);
                pessoa.validarCadastro(pessoas);
                pessoas.add(pessoa);
                System.out.println("Pessoa validada e adicionada.");
            }
            case "2" -> {
                Cliente cliente = new Cliente();
                cliente.lerDados(sc);
                cliente.validarCadastro(clientes, pessoas);
                clientes.add(cliente);
                pessoas.add(cliente.getPessoa());
                System.out.println("Cliente validado e adicionado.");
            }
            case "3" -> {
                Corrida corrida = new Corrida();
                corrida.lerDados(sc);
                corrida.validarAgendamento(corridas);
                corridas.add(corrida);
                System.out.println("Corrida validada e adicionada.");
            }
            case "4" -> {
                Pagamento pagamento = new Pagamento();
                pagamento.lerDados(sc);
                pagamento.validar();
                System.out.println(pagamento.gerarComprovante());
            }
            case "5" -> {
                Kart kart = new Kart();
                kart.lerDados(sc);
                kart.validar();
                System.out.println("Disponivel? " + kart.estaDisponivel());
            }
            default -> System.out.println("Opcao invalida.");
        }
    }
}
